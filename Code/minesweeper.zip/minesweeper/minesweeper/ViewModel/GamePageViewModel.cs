﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using minesweeper.Model;

namespace minesweeper.ViewModel
{
    public class GamePageViewModel : ViewModelBase
    {
        private ObservableCollection<Cell> cells;
        public ObservableCollection<Cell> Cells { get { return cells; } set { cells = value; RaisePropertyChanged("Cells"); } }
        
        public GamePageViewModel(int row, int col, int minenum)
        {
            //获取雷区的集合数据
            Cells = CellArea.GetCells(row, col, minenum);
        }
    }
}
