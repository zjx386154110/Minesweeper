﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Controls;
using minesweeper.ViewModel;
using minesweeper.Command;
using System.Collections.ObjectModel;

namespace minesweeper.Model
{
    //Cell类代表一个雷区中的一个格子
    public class Cell : ViewModelBase
    {
        private int x;
        public int X { get { return x; } set { x = value; RaisePropertyChanged("X"); } }

        private int y;
        public int Y { get { return y; } set { y = value; RaisePropertyChanged("Y"); } }

        private string imgsrc;
        public string ImgSrc { get { return imgsrc; } set { imgsrc = value; RaisePropertyChanged("ImgSrc"); } }

        private int minenum;
        public int MineNum { get { return minenum; } set { minenum = value; RaisePropertyChanged("MineNum"); } }
        
        public Cell(int x, int y)
        {
            X = x;        //行坐标
            Y = y;        //列坐标
            ImgSrc = "../Img/方块.png";  //显示图像路径
            MineNum = 0;           //-1代表格子为地雷，-2代表格子为控件，其他非负数代表格子周围含有的地雷数
        }

        //实现格子点击命令
        private DelegateCommand cellclick;
        public DelegateCommand CellClick
        {
            get{
                return cellclick ?? (cellclick = new DelegateCommand((Object obj) => {
                    CellArea.ClickCell(this);
                }, null));
            }
        }
    }
}
