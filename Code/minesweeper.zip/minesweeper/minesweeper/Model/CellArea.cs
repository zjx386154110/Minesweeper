﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Controls;
using minesweeper.ViewModel;
using System.Collections.ObjectModel;
using minesweeper.Command;
using Windows.UI.Xaml;

namespace minesweeper.Model
{
    public class CellArea : ViewModelBase
    {
        public static Cell[,] CellArray = new Cell[30, 30];  //用于存储雷区格子
        
        static public int Row;   //雷区行数
        static public int Col;   //雷区列数
        static public int MineSum;    //雷区未被标记的地雷数
        static public bool IsMarkMode;   //是否为标记模式
        static public bool IsFirstClick;  //是否为第一次打开格子
        static public bool IsFail;    //是否游戏失败
        
       //初始化并获取雷区
        static public ObservableCollection<Cell> GetCells(int row, int col, int minesum)
        {
            InitMine(row, col, minesum);
            ObservableCollection<Cell> Cells = new ObservableCollection<Cell>();
            for (int i = 0; i < Row; i++)
            {
                for (int j = 0; j < Col; j++)
                {
                    Cells.Add(CellArray[i, j]);
                }
            }
            return Cells;
        }
        //初始化雷区
        static void InitMine(int row, int col, int minesum)
        {
            //初始化数据
            Row = row;
            Col = col;
            MineSum = minesum;
            IsMarkMode = false;
            IsFirstClick = true;
            IsFail = false;
            for (int i = 0; i < Row; i++)
            {
                for (int j = 0; j < Col; j++)
                {
                    Cell newcell = new Cell(i, j);
                    CellArray[i, j] = newcell;
                }
            }
            //随机设置控件
            Random r = new Random();
            int randrow = r.Next(Row);
            int randcol = r.Next(Col);
            CellArray[randrow, randcol].ImgSrc = "../Img/标记关.png";
            CellArray[randrow, randcol].MineNum = -2;
            do
            {
                randrow = r.Next(Row);
                randcol = r.Next(Col);
            } while (CellArray[randrow, randcol].MineNum == -2);
            CellArray[randrow, randcol].ImgSrc = "../Img/退出.png";
            CellArray[randrow, randcol].MineNum = -2;
            do
            {
                randrow = r.Next(Row);
                randcol = r.Next(Col - 2);
            } while (CellArray[randrow, randcol].MineNum == -2 ||
                     CellArray[randrow, randcol + 1].MineNum == -2 ||
                     CellArray[randrow, randcol + 2].MineNum == -2);
            CellArray[randrow, randcol].ImgSrc = "../Img/雷数.png";
            CellArray[randrow, randcol].MineNum = -2;
            CellArray[randrow, randcol + 1].ImgSrc = "../Img/雷数" + (MineSum / 10).ToString() + ".png"; ;
            CellArray[randrow, randcol + 1].MineNum = -2;
            CellArray[randrow, randcol + 2].ImgSrc = "../Img/雷数" + (MineSum % 10).ToString() + ".png"; ;
            CellArray[randrow, randcol + 2].MineNum = -2;
            //随机布雷
            RandomMine();
        }
        //随机布雷
        static void RandomMine()
        {
            //重置数据
            for (int i = 0; i < Row; i++)
            {
                for (int j = 0; j < Col; j++)
                {
                    if (CellArray[i, j].MineNum != -2)
                    {
                        CellArray[i, j].MineNum = 0;
                        CellArray[i, j].ImgSrc = "../Img/方块.png";
                    }
                }
            }
            //随机布雷
            Random r = new Random();
            int randrow, randcol;
            for (int i = 0; i < MineSum; i++)
            {
                randrow = r.Next(Row);
                randcol = r.Next(Col);
                if (CellArray[randrow, randcol].MineNum == 0) CellArray[randrow, randcol].MineNum = -1;
                else i--;
            }
            //定义8个方向
            int[,] dir = new int[8, 2]{ {-1,-1}, {-1,0}, {-1,1}, {0,-1}, {0,1}, {1,0}, {1,1}, {1,-1}};
            //计算并设置每个格子周围雷数
            for (int i = 0; i < Row; i++)
            {
                for (int j = 0; j < Col; j++)
                {
                    if (CellArray[i, j].MineNum != -1 && CellArray[i, j].MineNum != -2)
                    {
                        for (int k = 0; k < 8; k++)
                        {
                            int x = CellArray[i, j].X + dir[k, 0];
                            int y = CellArray[i, j].Y + dir[k, 1];
                            if (x >= 0 && x < Row && y >= 0 && y < Col)
                                if (CellArray[x, y].MineNum == -1) CellArray[i, j].MineNum++;
                        }
                    }
                }
            }
        }
        //点击格子
        static public void ClickCell(Cell cell)
        {
            //判断是否为第一次点击
            if (IsFirstClick)
            {
                if (cell.MineNum == 0) IsFirstClick = false;
                //如果不是空白格子则重新布雷
                else if (cell.MineNum > 0 || cell.MineNum == -1)
                {
                    RandomMine();
                    ClickCell(CellArray[cell.X, cell.Y]);
                    IsFirstClick = false;
                    return;
                }
            }
            //判断游戏是否已失败
            if (IsFail) GameOver();
            //点击退出按钮
            else if (cell.ImgSrc == "../Img/退出.png")
            {
                QuitGame();
            }
            //点击标记模式开关
            else if (cell.ImgSrc == "../Img/标记关.png")
            {
                cell.ImgSrc = "../Img/标记开.png";
                IsMarkMode = true;
            }
            else if (cell.ImgSrc == "../Img/标记开.png")
            {
                cell.ImgSrc = "../Img/标记关.png";
                IsMarkMode = false;
            }
            else if (cell.MineNum != -2)
            {
                //标记格子
                if (IsMarkMode)
                {
                    if (cell.ImgSrc == "../Img/方块.png" || cell.ImgSrc == "../Img/旗子.png") MarkCell(cell);
                }
                //打开格子
                else if (cell.ImgSrc == "../Img/方块.png" || cell.ImgSrc == "../Img/旗子.png")
                {
                    OpenCell(cell);
                    //判断游戏是否胜利
                    if (CheckIfWin()) GameWin();
                }
            }
        }
        //标记格子并改变计数器数字
        static public void MarkCell(Cell cell)
        {
            if (cell.ImgSrc == "../Img/旗子.png")
            {
                cell.ImgSrc = "../Img/方块.png";
                SetMineSum(1);
            }
            else {
                cell.ImgSrc = "../Img/旗子.png";
                SetMineSum(-1);
            }
        }
        //改变计数器数字
        static public void SetMineSum(int n)
        {
            MineSum += n;
            if (MineSum >= 0)
            {
                for (int i = 0; i < Row; i++)
                {
                    for (int j = 0; j < Col; j++)
                    {
                        if (CellArray[i, j].ImgSrc == "../Img/雷数.png")
                        {
                            CellArray[i, j + 1].ImgSrc = "../Img/雷数" + (MineSum / 10).ToString() + ".png";
                            CellArray[i, j + 2].ImgSrc = "../Img/雷数" + (MineSum % 10).ToString() + ".png";
                        }
                    }
                }
            }
        }
        //点开格子
        static public void OpenCell(Cell cell)
        {
            if (cell.ImgSrc == "../Img/旗子.png") SetMineSum(1);
            //点击到地雷
            if (cell.MineNum == -1)
            {
                cell.ImgSrc = "../Img/地雷.png";
                for (int i = 0; i < Row; i++)
                {
                    for (int j = 0; j < Col; j++)
                    {
                        if (CellArray[i, j].MineNum == -1)
                        {
                            CellArray[i, j].ImgSrc = "../Img/地雷.png";
                        }
                    }
                }
                IsFail = true;
            }
            //点击到空白格子，则展开空白区域
            else if (cell.MineNum == 0 && cell.ImgSrc != "../Img/空白.png")
            {
                cell.ImgSrc = "../Img/空白.png";
                //定义8个方向
                int[,] dir = new int[8, 2] { { -1, -1 }, { -1, 0 }, { -1, 1 }, { 0, -1 }, { 0, 1 }, { 1, 0 }, { 1, 1 }, { 1, -1 } };
                for (int k = 0; k < 8; k++)
                {
                    int x = cell.X + dir[k, 0];
                    int y = cell.Y + dir[k, 1];
                    if (x >= 0 && x < Row && y >= 0 && y < Col)
                    {
                        if (CellArray[x, y].ImgSrc != "../Img/空白.png")
                        {
                            OpenCell(CellArray[x, y]);
                        }
                    }
                }
            }
            //点击到数字
            else if (cell.MineNum != 0 && cell.MineNum != -2)
            {
                cell.ImgSrc = "../Img/数字" + cell.MineNum.ToString() + ".png";
            }
        }
        //检查是否游戏胜利
        static bool CheckIfWin()
        {
            for (int i = 0; i < Row; i++)
            {
                for (int j = 0; j < Col; j++)
                {
                    if (CellArray[i, j].ImgSrc == "../Img/方块.png" && CellArray[i, j].MineNum != -1) return false;
                    if (CellArray[i, j].ImgSrc == "../Img/旗子.png" && CellArray[i, j].MineNum != -1) return false;
                }
            }
            return true;
        }
        //游戏胜利
        static void GameWin()
        {
            Frame root = Window.Current.Content as Frame;
            root.Navigate(typeof(WinPage));
        }
        //游戏失败
        static void GameOver()
        {
            Frame root = Window.Current.Content as Frame;
            root.Navigate(typeof(OverPage));
        }
        //退出游戏
        static void QuitGame()
        {
            Frame root = Window.Current.Content as Frame;
            root.Navigate(typeof(MainPage));
        }
    }
}
