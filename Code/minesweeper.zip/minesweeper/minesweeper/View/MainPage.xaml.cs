﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

using Windows.ApplicationModel;
using Windows.ApplicationModel.Activation;

using Windows.Storage;
using Windows.UI.Core;
using NotificationsExtensions.Tiles;
using Windows.UI.Notifications;
//“空白页”项模板在 http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409 上有介绍

namespace minesweeper
{
    /// <summary>
    /// 可用于自身或导航至 Frame 内部的空白页。
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
            TileContent content = createTile();
            UpdateTile(content);
        }

        private void NewGameClick(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(LevelPage));
        }

        private void GameHelp(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(HelpPage));
        }
        private void EXIT(object sender, RoutedEventArgs e)
        {
            Application.Current.Exit();
        }
        //private void uptile(object sender, RoutedEventArgs e)
        //{

        //    TileContent content = createTile();
        //    UpdateTile(content);
        //}
        private void UpdateTile(TileContent content)
        {
            // Create a tile update manager for the specified syndication feed.
            var updater = TileUpdateManager.CreateTileUpdaterForApplication();
            updater.Update(new TileNotification(content.GetXml()));
        }

        private TileContent createTile()
        {
            return new TileContent()
            {
                Visual = new TileVisual()
                {
                    TileSmall = new TileBinding()
                    {
                        Content = new TileBindingContentAdaptive()
                        {
                            Children = {
                                new TileText()
                                {
                                    Text = "扫雷",
                                    Style = TileTextStyle.Subtitle
                                },

                                new TileText()
                                {
                                    Text = "扫雷",
                                    Style = TileTextStyle.CaptionSubtle
                                },
                            }
                        }
                    },
                    TileMedium = new TileBinding()
                    {
                        Content = new TileBindingContentAdaptive()
                        {
                            Children = {
                                new TileText()
                                {
                                   Text = "扫雷",
                                    Style = TileTextStyle.Subtitle
                                },

                                new TileText()
                                {
                                    Text = "扫雷",
                                    Style = TileTextStyle.CaptionSubtle
                                },
                            }
                        }
                    },
                    TileWide = new TileBinding()
                    {
                        Content = new TileBindingContentAdaptive()
                        {
                            Children = {
                                new TileText()
                                {
                                    Text = "扫雷",
                                    Style = TileTextStyle.Subtitle
                                },

                                new TileText()
                                {
                                   Text = "扫雷",
                                    Style = TileTextStyle.CaptionSubtle
                                },
                            }
                        }
                    },
                }
            };
        }
    }
}
